let task = document.getElementsByClassName("task")[0];
let add_item = document.getElementById("add_item");
let task_list = document.getElementById("task_list");

function add_task() {
    let task_text = String(task.value);
    if (task_text === '') { // If the user clicks the add button without writing anything in the textbox.
        alert("You haven't entered a task yet.");
        task.style.cursor = "text";
        return;
    }
    // task_text.style.marginLeft = "15px";
    // Create the list item
    let list_item = document.createElement("li");
    let check_item = document.createElement("input");
    check_item.type = "checkbox";
    check_item.style.cursor = "pointer";
    check_item.style.marginRight = "17px";
    check_item.style.height = "15px";
    check_item.style.width = "18px";
    check_item.style.marginTop = "5px";

    list_item.appendChild(check_item);
    let task_node = document.createTextNode(task_text);
    list_item.appendChild(task_node);

    check_item.addEventListener('change', function() {
        if (this.checked){
            // console.log("Checkbox is checked."); 
            // console.log(list_item.children)
            list_item.style.opacity = 0.3;
            delete_btn.disabled = true;
        } else {
            list_item.style.opacity = 1;
            delete_btn.disabled = false;
        }
    });
    // task_node.style.marginLeft = "15px";
    // Create the delete button with FontAwesome trash icon
    let delete_btn = document.createElement("button");
    delete_btn.innerHTML = '<i class="fa fa-trash"></i>'; // Add FontAwesome trash icon
    delete_btn.style.background = "none" // Transparent background
    delete_btn.style.border = "none"; // No border
    delete_btn.style.color = "red"; // Red color for the trash icon
    delete_btn.style.cursor = "pointer"; // Pointer cursor on hover
    delete_btn.style.marginLeft = "17px"; // Space between the task and the trash icon
    delete_btn.style.fontSize = "20px";
    // Add an event listener to delete the list item when the button is clicked
    delete_btn.addEventListener("click", () => {
        task_list.removeChild(list_item);
    });

    // Append the delete button to the list item
    list_item.appendChild(delete_btn);

    // Append the list item to the task list
    task_list.appendChild(list_item);

    // Clear the input field
    task.value = '';
    console.log(list_item);
}

